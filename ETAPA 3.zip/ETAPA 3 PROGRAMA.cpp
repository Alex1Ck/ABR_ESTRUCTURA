#include <iostream>
using namespace std;

// Estructura de cada miembro del �rbol geneal�gico
struct Nodo {
    string nombre;
    int nacimiento;
    int fallecimiento;
    Nodo* izquierda;
    Nodo* derecha;

    Nodo(string nom, int nac, int fall) {
        nombre = nom;
        nacimiento = nac;
        fallecimiento = fall;
        izquierda = derecha = NULL;
    }
};

// Insertar nuevo miembro al �rbol
Nodo* insertar(Nodo* raiz, string nombre, int nac, int fall) {
    if (raiz == NULL) {
        return new Nodo(nombre, nac, fall);
    }
    if (nombre < raiz->nombre) {
        raiz->izquierda = insertar(raiz->izquierda, nombre, nac, fall);
    } else if (nombre > raiz->nombre) {
        raiz->derecha = insertar(raiz->derecha, nombre, nac, fall);
    }
    return raiz;
}

// Buscar un miembro por nombre
Nodo* buscar(Nodo* raiz, string nombre) {
    if (raiz == NULL || raiz->nombre == nombre) {
        return raiz;
    }
    if (nombre < raiz->nombre) {
        return buscar(raiz->izquierda, nombre);
    } else {
        return buscar(raiz->derecha, nombre);
    }
}

// Encontrar el nodo m�s peque�o (para eliminar)
Nodo* encontrarMinimo(Nodo* nodo) {
    while (nodo->izquierda != NULL) {
        nodo = nodo->izquierda;
    }
    return nodo;
}

// Eliminar un miembro
Nodo* eliminar(Nodo* raiz, string nombre) {
    if (raiz == NULL) return NULL;

    if (nombre < raiz->nombre) {
        raiz->izquierda = eliminar(raiz->izquierda, nombre);
    } else if (nombre > raiz->nombre) {
        raiz->derecha = eliminar(raiz->derecha, nombre);
    } else {
        if (raiz->izquierda == NULL && raiz->derecha == NULL) {
            delete raiz;
            return NULL;
        } else if (raiz->izquierda == NULL) {
            Nodo* temp = raiz->derecha;
            delete raiz;
            return temp;
        } else if (raiz->derecha == NULL) {
            Nodo* temp = raiz->izquierda;
            delete raiz;
            return temp;
        }
        Nodo* temp = encontrarMinimo(raiz->derecha);
        raiz->nombre = temp->nombre;
        raiz->nacimiento = temp->nacimiento;
        raiz->fallecimiento = temp->fallecimiento;
        raiz->derecha = eliminar(raiz->derecha, temp->nombre);
    }
    return raiz;
}

// Recorrido inorden (izquierda - ra�z - derecha)
void mostrarInorden(Nodo* raiz) {
    if (raiz == NULL) return;
    mostrarInorden(raiz->izquierda);
    cout << raiz->nombre << " (" << raiz->nacimiento << " - " << raiz->fallecimiento << ")\n";
    mostrarInorden(raiz->derecha);
}

// Recorrido preorden (ra�z - izquierda - derecha)
void mostrarPreorden(Nodo* raiz) {
    if (raiz == NULL) return;
    cout << raiz->nombre << " (" << raiz->nacimiento << " - " << raiz->fallecimiento << ")\n";
    mostrarPreorden(raiz->izquierda);
    mostrarPreorden(raiz->derecha);
}

// Recorrido postorden (izquierda - derecha - ra�z)
void mostrarPostorden(Nodo* raiz) {
    if (raiz == NULL) return;
    mostrarPostorden(raiz->izquierda);
    mostrarPostorden(raiz->derecha);
    cout << raiz->nombre << " (" << raiz->nacimiento << " - " << raiz->fallecimiento << ")\n";
}

// Men� principal
int main() {
    Nodo* raiz = NULL;
    int opcion;
    string nombre;
    int nac, fall;

    do {
        cout << "\n======= ARBOL GENEALOGICO =======\n";
        cout << "1. Insertar miembro\n";
        cout << "2. Eliminar miembro\n";
        cout << "3. Buscar miembro\n";
        cout << "4. Mostrar Inorden\n";
        cout << "5. Mostrar Preorden\n";
        cout << "6. Mostrar Postorden\n";
        cout << "7. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Nombre: ";
                cin >> nombre;
                cout << "A�o de nacimiento: ";
                cin >> nac;
                cout << "A�o de fallecimiento: ";
                cin >> fall;
                raiz = insertar(raiz, nombre, nac, fall);
                break;
            case 2:
                cout << "Nombre del miembro a eliminar: ";
                cin >> nombre;
                raiz = eliminar(raiz, nombre);
                break;
            case 3:
                cout << "Nombre a buscar: ";
                cin >> nombre;
                if (buscar(raiz, nombre)) {
                    cout << "Miembro encontrado en el �rbol.\n";
                } else {
                    cout << "No se encontr� el miembro.\n";
                }
                break;
            case 4:
                cout << "\n-- Recorrido Inorden --\n";
                mostrarInorden(raiz);
                break;
            case 5:
                cout << "\n-- Recorrido Preorden --\n";
                mostrarPreorden(raiz);
                break;
            case 6:
                cout << "\n-- Recorrido Postorden --\n";
                mostrarPostorden(raiz);
                break;
            case 7:
                cout << "Saliendo del programa.\n";
                break;
            default:
                cout << "Opci�n no v�lida.\n";
        }

    } while (opcion != 7);

    return 0;
}

